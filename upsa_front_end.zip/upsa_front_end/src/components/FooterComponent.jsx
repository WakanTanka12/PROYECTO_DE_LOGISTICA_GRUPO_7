import React from 'react'

const FooterComponent = () => {
    return (
        <div>
            <footer className="footer">
                <span>All Rights Reserved 2025 By Tito Zúñiga</span>
            </footer>
        </div>
    )
}
export default FooterComponent

